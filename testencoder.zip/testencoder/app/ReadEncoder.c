/*Description
 *Clock Configuration: HCLK: 64MHz
 *Peripherals:
 **TIM2: Slave Mode: External Clock Mode 1; Trigger Source: TI1FP1; Counter Period: 0xffff; Trigger Filter: 15
 **TIM3: Internal Clock; Prescaler: 63; Counter Period: 9999
 **USART1:
 *Pin:
 **PA0: TIM2_CH1
 **PA9: USART1_TX
 **PA10: USART1_RX
*/
#include "ReadEncoder.h"

/*uint16_t vec = 0;
uint8_t ngan = 0;
uint8_t tram = 0;
uint8_t chuc = 0;
uint8_t dvi = 0;
uint8_t* tmp;
uint8_t* space = " ";*/

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;

volatile uint16_t count = 0;
volatile uint16_t count1 = 0;
extern volatile uint8_t duty;
volatile float duty1;
volatile float set=1000;

uint8_t x = 0;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) //count chuan: 300,12V, pwm chuan: 80
{
	if (__HAL_TIM_GET_IT_SOURCE(&htim3, TIM_IT_UPDATE))
	{
	count = __HAL_TIM_GET_COUNTER(&htim2);			//290 - 12V - 480rpm
	//vec = (count*5/3 );							//tinh toc do
	/*ngan = (uint8_t)((vec / 1000)+48);
	tram = (uint8_t)((vec - (ngan-48) * 1000)/100+48);
	chuc = (uint8_t)((vec - (ngan-48) * 1000 - (tram-48)*100)/10+48);
	dvi = (uint8_t)((vec - (ngan-48) * 1000 - (tram-48) * 100 - (chuc-48) * 10)+48);
*/
	count1 = count*5;
	duty1 = PID(set, (float)count1);
	duty = (uint8_t)(duty1*66/1000);
	__HAL_TIM_SET_COUNTER(&htim2, 0);

	x++;
	if (x == 200)
	{
		if (set == 1000) set = 0;
		else set = 1000;
		x = 0;
	}
	//HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);		//tin hieu debug
	}
}

float PID(float setpoint, float measure)
{
	static volatile float e0 = 0;
	static volatile float e1 = 0;
	static volatile float e2 = 0;
	static volatile float u0 = 0;
	static volatile float u1 = 0;
	e2 = e1;
	e1 = e0;
	e0 = setpoint - measure;
	u1 = u0;
	u0 = (u1 + kp*(e0 - e1) + ki*time*(e0 + e1)/2 + kd*(e0 - 2*e1 + e2)/time);
	//if (u0 < 0 ) u0 = 0;
	//if (u0>1500 ) u0 =1500;
	if (u0 < 0 )	return 0;
	else return u0;
}
