#include "main.h"

#define kp 20
#define ki 5
#define kd 0.001
#define time 0.01

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);
float PID(float setpoint, float measure);
